const $ = (el, s) => el.querySelector(s);
const $$ = (el, s) => [...el.querySelectorAll(s)];
export const settings = (el) => {
  try { return JSON.parse(el?.getAttribute('data-settings') || '{}'); }
  catch { return {}; }
};
const reduce = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
const animation = (el) => {
  const z = settings(el);
  return [z._animation || z.animation || '', +(z._animation_delay || z.animation_delay || 0)];
};
export function startReveals(root) {
  const observed = [];
  const timeout = new Set();
  const show = (el) => {
    const [effect, delay] = animation(el);
    observer?.unobserve(el);
    if (!effect || effect === 'none' || reduce()) {
      el.classList.remove('elementor-invisible');
      return;
    }
    const timer = setTimeout(() => {
      timeout.delete(timer);
      el.classList.remove('elementor-invisible');
      el.classList.add('animated', effect);
    }, delay);
    timeout.add(timer);
  };
  const observer = 'IntersectionObserver' in globalThis ? new IntersectionObserver((entries) => {
    for (const e of entries) if (e.isIntersecting) show(e.target);
  }, { rootMargin: '0px 0px -6% 0px', threshold: 0 }) : null;
  $$(root, '.elementor-invisible').forEach(el => {
    if (el.closest('#wdt-advanced-carousel-swiper-087b773')) return;
    if (!animation(el)[0] || reduce() || !observer) show(el);
    else { observer.observe(el); observed.push(el); }
  });
  return () => {
    observer?.disconnect();
    timeout.forEach(clearTimeout);
    observed.forEach(el => el.classList.remove('elementor-invisible'));
  };
}
export function bindCarousel(swiper) {
  const wrap = $(swiper, ':scope > .swiper-wrapper');
  if (!wrap) return () => {};
  const widget = swiper.closest('.elementor-widget');
  const cfg = { ...settings(widget), ...settings(swiper) };
  const slides = $$(wrap, ':scope > .swiper-slide');
  if (!slides.length) return () => {};
  const originals = slides.filter(s => !s.classList.contains('swiper-slide-duplicate'));
  const clonedStart = slides.indexOf(originals[0]);
  const loop = cfg.loop === 'yes' && clonedStart > 0;
  const fade = cfg.effect === 'fade';
  const hero = swiper.id.endsWith('087b773');
  const prev = $(widget, '.wdt-arrow-pagination-prev');
  const next = $(widget, '.wdt-arrow-pagination-next');
  const gapSnapshot = parseFloat(originals[0]?.style.marginRight || '') || 0;
  const speed = reduce() ? 0 : +(cfg.speed || 300);
  let at = Math.max(0, clonedStart), lastActive = null, pc = 1, width = 0;
  let running, swipe, autoplay, unbinds = [];
  const later = new Set();
  const bind = (el, ev, cb, opt) => {
    if (!el) return;
    el.addEventListener(ev, cb, opt);
    unbinds.push(() => el.removeEventListener(ev, cb, opt));
  };
  const delay = (fn, ms) => {
    let timer = setTimeout(() => { later.delete(timer); fn(); }, ms);
    later.add(timer);
    return timer;
  };
  function playHero(active) {
    if (!hero || lastActive === active) return;
    lastActive = active;
    for (const s of slides) {
      s.classList.toggle('react-hero-visible', s === active);
      for (const layer of $$(s, '.elementor-element[data-settings]')) {
        const [ani] = animation(layer);
        if (!ani || ani === 'none') continue;
        layer.classList.remove('animated', ani);
        layer.classList.add('elementor-invisible');
      }
    }
    for (const layer of $$(active, '.elementor-element[data-settings]')) {
      const [ani, lag] = animation(layer);
      if (!ani || ani === 'none') continue;
      delay(() => {
        if (active !== lastActive) return;
        layer.classList.remove('elementor-invisible');
        if (!reduce()) layer.classList.add('animated', ani);
      }, reduce() ? 0 : lag);
    }
  }
  function visibleCount() {
    const w = innerWidth;
    const exact = cfg.responsive?.filter(v => w >= Number(v.breakpoint)).at(-1);
    if (exact?.toshow) return +exact.toshow;
    const desktop = +cfg.slides_to_show_opts || 1;
    if (w <= 575) return +cfg.slides_to_show_opts_mobile || 1;
    if (w <= 767) return +cfg.slides_to_show_opts_mobile_extra || 1;
    if (w <= 1024) return +cfg.slides_to_show_opts_tablet || Math.min(2, desktop);
    if (w <= 1200) return +cfg.slides_to_show_opts_tablet_extra || desktop;
    return +cfg.slides_to_show_opts_laptop || desktop;
  }
  function draw(animated = false) {
    const duration = animated ? speed : 0;
    wrap.style.transitionDuration = duration + 'ms';
    wrap.style.transform = fade ? 'translate3d(0,0,0)' : 'translate3d(' +
      (-at * (width + gapSnapshot) + (cfg.centered_slides === 'yes' ? (swiper.clientWidth - width) / 2 : 0)) + 'px,0,0)';
    slides.forEach((slide, i) => {
      const active = i === at;
      const visible = fade ? active : i >= at - (cfg.centered_slides === 'yes' ? Math.floor(pc / 2) : 0) &&
        i < at - (cfg.centered_slides === 'yes' ? Math.floor(pc / 2) : 0) + pc;
      slide.classList.toggle('swiper-slide-active', active);
      slide.classList.toggle('swiper-slide-visible', visible);
      slide.classList.toggle('swiper-slide-prev', i === at - 1);
      slide.classList.toggle('swiper-slide-next', i === at + 1);
      slide.setAttribute('aria-hidden', String(!visible));
      slide.toggleAttribute('inert', !visible);
      if (fade) {
        slide.style.transform = 'translate3d(' + -(i * (width + gapSnapshot)) + 'px,0,0)';
        slide.style.opacity = active ? '1' : '0';
        slide.style.transitionDuration = duration + 'ms';
        slide.style.zIndex = active ? '2' : '1';
      }
    });
    const stop = Math.max(0, originals.length - pc);
    for (const [a, disabled] of [[prev, !loop && at <= 0], [next, !loop && at >= stop]]) {
      a?.classList.toggle('swiper-button-disabled', disabled);
      a?.setAttribute('aria-disabled', String(disabled));
    }
    playHero(slides[at]);
  }
  function size() {
    if (!swiper.clientWidth) return;
    pc = Math.min(visibleCount(), originals.length) || 1;
    width = (swiper.clientWidth - (pc - 1) * gapSnapshot) / pc;
    if (!loop) at = Math.min(at, Math.max(0, originals.length - pc));
    for (const s of slides) {
      s.style.width = width + 'px';
      s.style.marginRight = gapSnapshot + 'px';
    }
    draw(false);
  }
  function step(d) {
    if (running) return;
    const end = Math.max(0, originals.length - pc);
    const exact = cfg.responsive?.filter(v => innerWidth >= Number(v.breakpoint)).at(-1);
    const by = +exact?.toscroll || +cfg.slides_to_scroll || (cfg.slides_to_scroll_opts === 'all' ? pc : 1);
    const to = loop ? at + d * by : Math.max(0, Math.min(end, at + d * by));
    if (to < 0 || to >= slides.length || at === to) return;
    at = to;
    draw(true);
    running = delay(() => {
      running = null;
      if (loop && (at < clonedStart || at >= clonedStart + originals.length)) {
        at = ((at - clonedStart + originals.length) % originals.length) + clonedStart;
        draw(false);
      }
    }, speed);
  }
  for (const [a, d, description] of [[prev, -1, 'Previous slide'], [next, 1, 'Next slide']]) {
    if (!a) continue;
    a.setAttribute('role', 'button');
    a.setAttribute('tabindex', '0');
    a.setAttribute('aria-label', description);
    bind(a, 'click', (e) => { e.preventDefault(); step(d); });
    bind(a, 'keydown', (e) => { if (['Enter', ' '].includes(e.key)) { e.preventDefault(); step(d); } });
  }
  bind(swiper, 'pointerdown', e => { swipe = [e.clientX, e.clientY]; }, { passive: true });
  bind(swiper, 'pointerup', e => {
    if (!swipe) return;
    const x = e.clientX - swipe[0], y = e.clientY - swipe[1];
    swipe = null;
    if (Math.abs(x) > 50 && Math.abs(x) > Math.abs(y) * 1.4) step(x < 0 ? 1 : -1);
  }, { passive: true });
  bind(swiper, 'pointercancel', () => { swipe = null; }, { passive: true });
  if (cfg.autoplay === 'yes') {
    const start = () => {
      clearInterval(autoplay);
      if (!reduce() && document.visibilityState === 'visible') autoplay = setInterval(() => step(1), +(cfg.autoplay_speed || cfg.autoplay_delay || 5000));
    };
    const stop = () => clearInterval(autoplay);
    bind(swiper, 'pointerenter', stop);
    bind(swiper, 'pointerleave', start);
    bind(swiper, 'focusin', stop);
    bind(swiper, 'focusout', start);
    bind(document, 'visibilitychange', start);
    start();
  }
  const observer = 'ResizeObserver' in globalThis ? new ResizeObserver(size) : null;
  observer?.observe(swiper);
  bind(window, 'resize', size, { passive: true });
  size();
  return () => { unbinds.forEach(fn => fn()); observer?.disconnect(); later.forEach(clearTimeout); clearInterval(autoplay); };
}
