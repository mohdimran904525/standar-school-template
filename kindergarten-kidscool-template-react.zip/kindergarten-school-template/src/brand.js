// Change these values for a school-specific version. Files in public/assets/media
// are shared across every appearance, including slides, cards and popups.
export const brand = {
  title: 'KidsCool | Kindergarten School Template',
  name: 'KidsCool',
  logo: '/assets/media/kidslogo.png',
  lightLogo: '/assets/media/kidslightlogo.png',
  phoneDisplay: '+000 - 123 - 456789',
  phoneHref: '', // Use the verified Justdial number when one is available.
  email: 'info@example.com',
  emailHref: '', // Add the real inbox before enabling mailto.
  newsletterPopup: true,
  newsletterDelay: 200,
  // Add entries here to change a graphic everywhere without touching layout:
  images: {
    // '/assets/media/Slider-without-content.jpg': '/assets/media/your-hero.jpg',
  },
  // An empty object preserves the exact reference palette. Set CSS custom properties
  // here when rebranding. See README for the primary and secondary theme variables.
  palette: {},
};
