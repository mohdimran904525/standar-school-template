import React, { memo, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createPortal } from 'react-dom';
import documentSpec from './reference/document.json';
import { brand } from './brand.js';
import { installInteractions } from './site-interactions.js';
import './react-enhancements.css';

const imported = import.meta.glob('./reference/*.html', { eager: true, query: '?raw', import: 'default' });
const escape = value => String(value ?? '').replace(/[&<>"']/g, symbol => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[symbol]);
const paletteAssetKey = path => '--kid-image-' + path.split('/').at(-1).toLowerCase().replace(/[^a-z0-9]+/g, '-');
const sections = new Map([
  ['hero','home'],['introduction','about'],['learning-programs','programs'],['creative-learning','creative-learning'],
  ['school-campus','campus'],['school-community','community'],['campus-gallery','gallery'],
  ['teachers','teachers'],['activities','activities'],['articles','articles'],
  ['teaching-methods','teaching-methods'],['testimonials','testimonials'],['newsletter','newsletter']
]);
const labels = {
  about: 'About the school', programs: 'Education programmes', 'creative-learning': 'Creative learning',
  campus: 'School campus', community: 'Student community', gallery: 'Campus gallery',
  teachers: 'Teachers and trainers', activities: 'Smart activities', articles: 'School articles',
  'teaching-methods': 'Teaching methodology', testimonials: 'Parent testimonials', newsletter: 'Newsletter',
};
const dests = {
  '': '#home', 'home/': '#home', 'about-us/': '#about', 'lms/': '#programs',
  'infrastructure/': '#campus', 'infrastructure': '#campus', 'team/': '#teachers',
  'blog/': '#articles', 'contact-us/': '#footer',
};
function renderFragment(name) {
  let source = imported['./reference/' + name + '.html'] || '';
  source = source.replace(/href="https:\/\/wdtkidscool\.wpenginepowered\.com\/([^"]*)"/g,
    (match, path) => dests[path] ? 'href="' + dests[path] + '"' : match);
  source = source.replace(/\/assets\/media\/kidslightlogo\.png/g, escape(brand.lightLogo))
    .replace(/\/assets\/media\/kidslogo\.png/g, escape(brand.logo))
    .replace(/Kidscool Site/g, escape(brand.name));
  source = source.replace(/tel:\+?0[\d\s-]+/gi, brand.phoneHref ? 'tel:' + escape(brand.phoneHref) : '#footer')
    .replace(/\+000\s*-\s*123\s*-\s*456789/g, escape(brand.phoneDisplay))
    .replace(/mailto:info@example\.com/g, brand.emailHref ? 'mailto:' + escape(brand.emailHref) : '#footer')
    .replace(/info@example\.com/g, escape(brand.email));
  for (const [from, to] of Object.entries(brand.images)) source = source.replaceAll(from, escape(to));
  return source;
}
const fragments = Object.fromEntries(Object.keys(imported).map(file => {
  const name = file.split('/').at(-1).replace(/\.html$/, '');
  return [name, { __html: renderFragment(name) }];
}));
const cssParser = document.createElement('div');
const domProps = ({class: className, style, ...attrs}) => {
  if (!style) return {className, ...attrs};
  cssParser.style.cssText = style;
  const declarations = {};
  for (let i = 0; i < cssParser.style.length; i++) {
    const name = cssParser.style.item(i);
    const key = name.startsWith('--') ? name : name.replace(/^-ms-/, 'ms-')
      .replace(/-([a-z])/g, (_, char) => char.toUpperCase());
    declarations[key] = cssParser.style.getPropertyValue(name);
  }
  return {className, ...attrs, style: declarations};
};
const Banner = memo(function Banner(){
  return <div {...domProps(documentSpec.headerAttributes)} dangerouslySetInnerHTML={fragments.header}/>;
});
const Footer = memo(function Footer(){
  return <footer {...domProps(documentSpec.footerAttributes)} dangerouslySetInnerHTML={fragments.footer}/>;
});
const Home = memo(function Home(){
  const [outer, container, page] = documentSpec.mainAttributes.map(domProps);
  return <main {...outer} tabIndex="-1">
    <div {...container}><div {...page}>
      {documentSpec.sections.map(([name, attributes]) => {
        const slug = sections.get(name);
        const attrs = domProps(attributes);
        return <section key={name} {...attrs} id={slug || attrs.id} aria-label={labels[slug]} dangerouslySetInnerHTML={fragments[name]}/>;
      })}
    </div></div>
  </main>;
});
function Dialog({modal, close}) {
  const box = useRef(null);
  const origin = useRef(null);
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState(false);
  useEffect(() => {
    if (!modal) return;
    origin.current = document.activeElement;
    const old = document.body.style.overflow;
    const rootOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    box.current?.querySelector(modal.type === 'search' ? 'input' : 'button')?.focus({preventScroll:true});
    const key = e => {
      if (e.key === 'Escape') close();
      if (e.key !== 'Tab' || !box.current) return;
      const opts = [...box.current.querySelectorAll('a[href], button, input, [tabindex="0"]')].filter(x => x.getClientRects().length);
      if (opts.length < 2) return;
      if (e.shiftKey && document.activeElement === opts[0]) { e.preventDefault(); opts.at(-1).focus(); }
      else if (!e.shiftKey && document.activeElement === opts.at(-1)) { e.preventDefault(); opts[0].focus(); }
    };
    addEventListener('keydown', key);
    return () => {
      removeEventListener('keydown', key);
      document.body.style.overflow = old;
      document.documentElement.style.overflow = rootOverflow;
      origin.current?.focus?.({preventScroll:true});
    };
  }, [modal, close]);
  if (!modal) return null;
  if (modal.type === 'newsletter') {
    const popupClasses = 'wdt-popup-box-window wdt-popup-box-window-e871b04 wdt-fade-zoom mfp-ready';
    return createPortal(<>
      <div className={'mfp-bg ' + popupClasses} />
      <div ref={box} className={'mfp-wrap mfp-auto-cursor ' + popupClasses} role="dialog" aria-modal="true" aria-label="Get Our Newsletter" onClick={e => { if (!e.target.closest('.mfp-content') || e.target.closest('.mfp-close')) { e.preventDefault(); close(); } }} onSubmit={e => { e.preventDefault(); if(e.target.reportValidity()) setSubmitted(true); }}>
        <div className="mfp-container mfp-inline-holder">
          <div className="mfp-content" dangerouslySetInnerHTML={fragments['newsletter-popup']}/>
          <button type="button" className="mfp-close" title="Close" aria-label="Close newsletter" onClick={close}>×</button>
        </div>
        {submitted && <span className="react-newsletter-status" role="status">Demo mode. No email was sent.</span>}
      </div>
    </>, document.body);
  }
  const imageName = modal.alt || 'Gallery photo';
  const matches = Object.entries(labels).filter(([,label]) => !query || label.toLowerCase().includes(query.toLowerCase()));
  return createPortal(<div className="react-dialog-backdrop" onClick={e => {if(e.target === e.currentTarget) close();}}>
    <div className={'react-dialog ' + (modal.type === 'search' ? 'react-search' : 'react-media')} ref={box} role="dialog" aria-modal="true" aria-label={modal.type === 'search' ? 'Search' : modal.type === 'video' ? 'Video' : imageName}>
      <button type="button" className="react-dialog-close" aria-label="Close dialog" onClick={close}>×</button>
      {modal.type === 'search' ? <>
        <h2>Search the school site</h2>
        <label htmlFor="local-query" className="screen-reader-text">Search sections</label>
        <input id="local-query" value={query} onChange={e => setQuery(e.target.value)} placeholder="Enter Keyword"/>
        {matches.length ? <ul>{matches.map(([id,name]) => <li key={id}><a href={'#' + id} onClick={close}>{name}</a></li>)}</ul> : <p>No sections found.</p>}
      </> : modal.type === 'video' ? <iframe title="Learning video" src={modal.url} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin"/> :
        <img src={modal.url} alt={imageName} />}
    </div>
  </div>, document.body);
}
function App(){
  const site = useRef(null);
  const [modal, setModal] = useState(null);
  const [showTop,setShowTop] = useState(false);
  const close = useCallback(() => {
    if (document.querySelector('.mfp-wrap[role="dialog"]')) {
      try { localStorage.setItem('kidscool-newsletter-dismissed',String(Date.now())); } catch {/* storage unavailable */}
    }
    setModal(null);
  }, []);
  useLayoutEffect(() => {
    const previous = document.body.className;
    document.body.className = documentSpec.pageClass;
    document.title = brand.title;
    for (const [name,value] of Object.entries(brand.palette)) {
      document.documentElement.style.setProperty(name,value);
      document.body.style.setProperty(name,value);
    }
    for (const [path,url] of Object.entries(brand.images))
      document.documentElement.style.setProperty(paletteAssetKey(path), 'url(' + JSON.stringify(url) + ')');
    const icon = document.querySelector('link[rel=icon]');
    if (icon) icon.href = brand.logo;
    const clean = installInteractions(site.current,{
      newsletter: () => setModal({type:'newsletter'}),
      search: () => setModal({type:'search'}),
      image: (url,alt) => setModal({type:'image',url,alt}),
      video: (src) => {
        try {
          const u = new URL(src);
          const v = u.searchParams.get('v');
          if (['www.youtube.com','youtube.com','m.youtube.com'].includes(u.hostname) && /^[\w-]{11}$/.test(v || ''))
            setModal({type:'video',url:'https://www.youtube-nocookie.com/embed/' + v + '?autoplay=1'});
        } catch {/* invalid rebrand URL */}
      }
    });
    return () => { clean(); document.body.className = previous; };
  }, []);
  useEffect(() => {
    const allowed = () => {
      try { return Date.now() - +(localStorage.getItem('kidscool-newsletter-dismissed') || '0') > 86400000; }
      catch { return true; }
    };
    const timer = brand.newsletterPopup && allowed() ? setTimeout(() => {
      setModal({type:'newsletter'});
    },brand.newsletterDelay) : null;
    const sticky = site.current.querySelector('.sticky-header-active');
    const scroll = () => {
      setShowTop(scrollY > 500);
      sticky?.classList.toggle('wdt-header-top', scrollY > 154);
      sticky?.toggleAttribute('inert', scrollY <= 154);
    };
    scroll();
    addEventListener('scroll', scroll, {passive:true});
    return () => { clearTimeout(timer); removeEventListener('scroll',scroll); };
  }, []);
  const [outer, inner] = documentSpec.wrapperAttributes.map(domProps);
  return <>
    <a className="skip-link screen-reader-text" href="#main">Skip to content</a>
    <div {...outer} ref={site}><div {...inner}><Banner/><Home/><Footer/></div></div>
    {showTop && <button className="react-back-top" type="button" aria-label="Back to top" onClick={() => scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'})}>↑</button>}
    {modal && <Dialog key={modal.type} modal={modal} close={close}/>}
  </>;
}
createRoot(document.querySelector('#root')).render(<App/>);
