import { bindCarousel, settings, startReveals } from './carousel.js';
const q = (ctx, css) => ctx.querySelector(css);
const qa = (ctx, css) => [...ctx.querySelectorAll(css)];
function startCounters(root) {
  if (!('IntersectionObserver' in globalThis) || matchMedia('(prefers-reduced-motion: reduce)').matches) return () => {};
  const timers = new Set();
  const observer = new IntersectionObserver(entries => {
    for (const e of entries) {
      if (!e.isIntersecting) continue;
      const n = e.target;
      observer.unobserve(n);
      const from = Number(n.dataset.from) || 0, to = Number(n.dataset.to);
      if (!Number.isFinite(to)) continue;
      const duration = Number(n.dataset.speed) || 1000, interval = Number(n.dataset.refreshInterval) || 100;
      let elapsed = 0;
      n.textContent = String(from);
      const timer = setInterval(() => {
        elapsed = Math.min(duration, elapsed + interval);
        n.textContent = String(Math.round(from + (to - from) * elapsed / duration));
        if (elapsed === duration) { clearInterval(timer); timers.delete(timer); }
      }, interval);
      timers.add(timer);
    }
  }, { threshold: 0.35 });
  qa(root, '.wdt-content-counter-number[data-to]').forEach(n => observer.observe(n));
  return () => { observer.disconnect(); timers.forEach(clearInterval); };
}
export function installInteractions(root, handlers) {
  const end = [startReveals(root), startCounters(root), ...qa(root, '.swiper[id]').map(bindCarousel)];
  const mobile = {};
  const configureTab = (node, focus = false) => {
    const list = node.closest('[role=tablist]');
    if (!list) return;
    const widget = list.closest('.elementor-widget');
    qa(list, '.ui-tabs-anchor').forEach(a => {
      const selected = a === node;
      const li = a.closest('li');
      li?.classList.toggle('ui-tabs-active', selected);
      li?.classList.toggle('ui-state-active', selected);
      li?.setAttribute('aria-selected', String(selected));
      li?.setAttribute('tabindex', selected ? '0' : '-1');
      a.setAttribute('aria-selected', String(selected));
      a.setAttribute('tabindex', selected ? '0' : '-1');
      const panel = widget && qa(widget, '.ui-tabs-panel').find(p => '#' + p.id === a.getAttribute('href'));
      if (panel) {
        panel.style.display = selected ? '' : 'none';
        panel.setAttribute('aria-hidden', String(!selected));
      }
    });
    if (focus) node.focus();
  };
  qa(root, '.wdt-tabs-list').forEach(list => {
    const first = q(list, '.ui-tabs-active a, a.ui-tabs-anchor');
    if (first) configureTab(first);
  });
  function onClick(event) {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const trigger = target.closest('a, button, [role=button], .elementor-custom-embed-image-overlay');
    if (!trigger) return;
    const tab = trigger.matches('.ui-tabs-anchor') ? trigger : null;
    if (tab) { event.preventDefault(); configureTab(tab, true); return; }
    if (trigger.matches('.wdt-search-icon')) { event.preventDefault(); handlers.search(); return; }
    if (trigger.matches('.menu-trigger')) {
      event.preventDefault();
      const shell = trigger.closest('.wdt-header-menu') || trigger.parentElement;
      const menu = q(shell, '.mobile-menu') || q(trigger.parentElement.parentElement, '.mobile-menu');
      const nav = q(shell, '.wdt-primary-nav > ul') || q(shell, '.wdt-primary-nav ul') || q(root, '#header .wdt-primary-nav ul');
      if (menu && nav) {
        if (!menu.children.length) {
          const copy = nav.cloneNode(true);
          for (const el of qa(copy, '[id]')) el.removeAttribute('id');
          menu.append(copy);
        }
        const active = !menu.classList.contains('react-mobile-menu-visible');
        if (mobile.menu && mobile.menu !== menu) mobile.menu.classList.remove('react-mobile-menu-visible');
        menu.classList.toggle('react-mobile-menu-visible', active);
        trigger.setAttribute('aria-expanded', String(active));
        mobile.menu = menu;
        mobile.trigger = trigger;
      }
      return;
    }
    if (trigger.matches('.elementor-custom-embed-image-overlay') || trigger.closest('.elementor-widget-video')) {
      const item = trigger.closest('.elementor-widget-video');
      const url = settings(item).youtube_url;
      if (url) { event.preventDefault(); handlers.video(url); }
      return;
    }
    if (trigger.closest('[id*=popup-box-trigger]') || trigger.matches('[href="#wdt-main-custom-popup-form"]')) {
      event.preventDefault(); handlers.newsletter(); return;
    }
    if (trigger.closest('figure.gallery-item, .gallery-icon')) {
      const image = q(trigger, 'img') || q(trigger.closest('figure') || trigger, 'img');
      if (image?.getAttribute('src')?.startsWith('/assets/')) {
        event.preventDefault(); handlers.image(image.getAttribute('src'), image.alt); return;
      }
    }
    if (mobile.menu && trigger.closest('.react-mobile-menu-visible')) {
      mobile.menu.classList.remove('react-mobile-menu-visible');
      mobile.trigger?.setAttribute('aria-expanded', 'false');
    }
  }
  function onKey(event) {
    const tab = event.target.closest?.('.ui-tabs-anchor');
    if (tab && ['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) {
      event.preventDefault();
      const all = qa(tab.closest('[role=tablist]'), '.ui-tabs-anchor'), i = all.indexOf(tab);
      configureTab(all[event.key === 'Home' ? 0 : event.key === 'End' ? all.length - 1 :
        (i + (event.key === 'ArrowLeft' ? -1 : 1) + all.length) % all.length], true);
    }
    if (event.key === 'Escape' && mobile.menu) {
      mobile.menu.classList.remove('react-mobile-menu-visible');
      mobile.trigger?.setAttribute('aria-expanded', 'false');
    }
  }
  function onForm(event) {
    event.preventDefault();
    const form = event.target;
    if (!form.reportValidity()) return;
    if (form.id === 'searchform') { handlers.search(); return; }
    if (!form.querySelector('.react-local-form-result')) {
      const status = document.createElement('p');
      status.className = 'react-local-form-result';
      status.setAttribute('role', 'status');
      status.textContent = 'Demo mode. This form does not send any information.';
      form.append(status);
    }
  }
  root.addEventListener('click', onClick);
  root.addEventListener('keydown', onKey);
  root.addEventListener('submit', onForm);
  return () => { end.forEach(fn => fn()); root.removeEventListener('click', onClick); root.removeEventListener('keydown', onKey); root.removeEventListener('submit', onForm); };
}
